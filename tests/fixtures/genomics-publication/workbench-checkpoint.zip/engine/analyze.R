#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(DESeq2))
suppressPackageStartupMessages(library(jsonlite))
stopifnot(as.character(packageVersion("DESeq2")) == "1.52.0")
args <- commandArgs(trailingOnly=TRUE)
if(length(args)!=1) stop("Expected one pinned engine input")
payload <- fromJSON(args[[1]], simplifyVector=FALSE)
o <- payload$options
a <- payload$audit
stopifnot(isTRUE(a$valid), a$contract == "genomics-audit-v1")
set.seed(260924)
warnings_seen <- character()
write_json_file <- function(x, file) write_json(x, file, auto_unbox=TRUE, pretty=TRUE, null="null", na="null", digits=16)
write_table <- function(x, file) write.csv(x, file, row.names=FALSE, na="", fileEncoding="UTF-8")
write_matrix <- function(x, file, key="gene_id") {
  con <- gzfile(file, "wt", encoding="UTF-8")
  on.exit(close(con))
  output <- cbind(data.frame(identity=rownames(x), check.names=FALSE), as.data.frame(x, check.names=FALSE))
  names(output)[[1]] <- key
  write.csv(output, con, row.names=FALSE, na="")
}
fail_qc <- function(message, qc) {
  qc$valid <- FALSE; qc$failure <- message
  write_json_file(qc, "design-audit.json")
  stop(message, call.=FALSE)
}
run <- function() {
  genes <- unlist(a$genes, use.names=FALSE)
  samples <- a$samples
  sample_ids <- vapply(samples, function(s) s$id, "")
  counts <- do.call(rbind, lapply(a$counts, unlist, use.names=FALSE))
  storage.mode(counts) <- "integer"
  dimnames(counts) <- list(genes, sample_ids)
  stopifnot(nrow(counts)==length(genes), ncol(counts)==length(samples), !anyNA(counts), all(counts>=0))
  conditions <- vapply(samples, function(s) s$condition, "")
  original_levels <- c(o$reference, setdiff(unique(conditions),o$reference))
  level_codes <- sprintf("level%03d", seq_along(original_levels))
  condition_map <- data.frame(original=original_levels, model=level_codes)
  coldata <- data.frame(row.names=sample_ids)
  coldata$condition <- factor(level_codes[match(conditions,original_levels)], levels=level_codes)
  formula_terms <- character()
  mappings <- list(condition=condition_map)
  for(key in c("subject","batch")) {
    if(!is.null(o[[paste0(key,"Column")]])) {
      raw <- vapply(samples, function(s) s[[key]], "")
      levels <- unique(raw); codes <- sprintf("level%03d",seq_along(levels))
      coldata[[key]] <- factor(codes[match(raw,levels)], levels=codes)
      mappings[[key]] <- data.frame(original=levels, model=codes)
      formula_terms <- c(formula_terms,key)
    }
  }
  scaling <- list()
  for(i in seq_along(o$numericCovariates)) {
    x <- vapply(samples,function(s) as.numeric(s$covariates[[i]]), 0)
    if(!all(is.finite(x)) || sd(x)==0) stop("Invalid continuous covariate")
    alias <- paste0("covariate",i)
    coldata[[alias]] <- as.numeric(scale(x))
    scaling[[alias]] <- list(source=o$numericCovariates[[i]],mean=mean(x),sd=sd(x))
    formula_terms <- c(formula_terms,alias)
  }
  design <- reformulate(c(formula_terms,"condition"))
  design_matrix <- model.matrix(design, coldata)
  rank <- qr(design_matrix)$rank
  qc <- list(contract="genomics-design-v1", valid=TRUE, formula=paste(deparse(design),collapse=""),
             n=nrow(design_matrix), parameters=ncol(design_matrix), rank=rank,
             residualDf=nrow(design_matrix)-rank, sampleOrder=as.list(sample_ids),
             conditionMapping=condition_map, factorMappings=mappings, covariateScaling=scaling,
             direction=list(numerator=o$numerator, reference=o$reference),
             interpretation="Positive log2 fold change means numerator greater than reference, conditional on the specified design.")
  write_table(cbind(data.frame(sample_id=sample_ids),design_matrix),"design-matrix.csv")
  write_json_file(qc,"design-audit.json")
  if(rank!=ncol(design_matrix)) fail_qc("Design matrix is not full rank. Batch, subject, condition or covariates are confounded; no terms were silently removed.",qc)
  if(qc$residualDf<1) fail_qc("No residual degrees of freedom; biological replication is required.",qc)
  keep <- rowSums(counts >= o$minCount) >= o$minSamples
  all_zero <- rowSums(counts)==0
  keep <- keep & !all_zero
  filters <- data.frame(gene_id=genes, above_min_count=rowSums(counts>=o$minCount), total_count=rowSums(counts),
                        retained=keep, reason=ifelse(all_zero,"all_zero",ifelse(keep,"retained","low_count")))
  write_table(filters,"gene-filter.csv")
  if(sum(keep)<2) fail_qc("Fewer than two genes pass the predeclared count filter; no differential model was fitted.",qc)
  if(sum(keep)<100) warnings_seen <<- c(warnings_seen,"Fewer than 100 genes pass prefiltering; dispersion trend and empirical information sharing may be unstable.")
  dds <- DESeqDataSetFromMatrix(countData=counts[keep,,drop=FALSE], colData=coldata, design=design)
  dds <- DESeq(dds, test="Wald", fitType=o$fitType, sfType=o$sizeFactor, betaPrior=FALSE,
               minReplicatesForReplace=Inf, parallel=FALSE, quiet=FALSE)
  contrast <- c("condition", level_codes[match(o$numerator,original_levels)], level_codes[match(o$reference,original_levels)])
  result <- results(dds, contrast=contrast, alpha=o$alpha, independentFiltering=o$independentFiltering,
                    lfcThreshold=o$lfcThreshold, altHypothesis="greaterAbs")
  without_cooks <- results(dds, contrast=contrast, alpha=o$alpha, independentFiltering=FALSE,
                           cooksCutoff=FALSE, lfcThreshold=o$lfcThreshold, altHypothesis="greaterAbs")
  raw_result <- as.data.frame(result)
  normalized <- sweep(counts, 2, sizeFactors(dds), "/")
  output <- data.frame(gene_id=genes, status=filters$reason, baseMean=rowMeans(normalized),
                       log2FoldChange=NA_real_, lfcSE=NA_real_, lfcLower95=NA_real_, lfcUpper95=NA_real_,
                       stat=NA_real_, pvalue=NA_real_, padj=NA_real_, dispersion=NA_real_,
                       significant=FALSE, stringsAsFactors=FALSE)
  idx <- which(keep)
  for(key in c("baseMean","log2FoldChange","lfcSE","stat","pvalue","padj")) output[idx,key] <- raw_result[[key]]
  output$dispersion[idx] <- dispersions(dds)
  output$lfcLower95[idx] <- raw_result$log2FoldChange-qnorm(.975)*raw_result$lfcSE
  output$lfcUpper95[idx] <- raw_result$log2FoldChange+qnorm(.975)*raw_result$lfcSE
  status <- rep("tested",length(idx))
  status[is.finite(raw_result$pvalue) & !is.finite(raw_result$padj)] <- "independent_filtered"
  status[!is.finite(raw_result$pvalue)] <- "not_estimable"
  status[!is.finite(raw_result$pvalue) & is.finite(without_cooks$pvalue)] <- "cooks_outlier"
  output$status[idx] <- status
  output$significant <- is.finite(output$padj) & output$padj < o$alpha
  write_table(output,"differential-expression.csv")
  write_matrix(normalized,"normalized-counts.csv.gz")
  sample_qc <- data.frame(sample_id=sample_ids,condition=conditions,
                         total_counts=colSums(counts),detected_genes=colSums(counts>0),
                         retained_counts=colSums(counts[keep,,drop=FALSE]),size_factor=as.numeric(sizeFactors(dds)))
  for(key in c("batch","subject")) if(!is.null(o[[paste0(key,"Column")]])) sample_qc[[key]] <- vapply(samples,function(s)s[[key]],"")
  write_table(sample_qc,"sample-qc.csv")
  cooked <- assays(dds)[["cooks"]]
  if(!is.null(cooked))write_matrix(cooked,"cooks-distances.csv.gz")
  saveRDS(dds,"deseq2-fit.rds",compress="xz")

  universe <- output$gene_id[is.finite(output$padj)]
  selected <- output$gene_id[output$significant]
  if(!is.null(o$geneSets) && o$geneSets$direction!="both") {
    direction <- if(o$geneSets$direction=="up") output$log2FoldChange>0 else output$log2FoldChange<0
    selected <- output$gene_id[output$significant & !is.na(direction) & direction]
  }
  enrichment <- list(status="not_requested")
  sets_output <- NULL
  if(!is.null(o$geneSets)) {
    write_table(data.frame(gene_id=universe),"enrichment-universe.csv")
    write_table(data.frame(gene_id=selected),"enrichment-selected.csv")
    sets_output <- do.call(rbind,lapply(a$geneSets,function(s) {
      original <- unique(unlist(s$genes,use.names=FALSE))
      members <- intersect(original,universe)
      N <- length(universe); M <- length(members); n <- length(selected)
      hits <- intersect(members,selected); k <- length(hits)
      state <- if(N==0) "empty_universe" else if(M<o$geneSets$minSize) "below_min_size" else if(M>o$geneSets$maxSize) "above_max_size" else "tested"
      p <- if(state=="tested") phyper(k-1,M,N-M,n,lower.tail=FALSE) else NA_real_
      data.frame(set_id=s$id,status=state,original_size=length(original),universe_size=N,eligible_size=M,
                 outside_universe=length(setdiff(original,universe)),selected_genes=n,overlap=k,
                 fold_enrichment=if(n>0 && M>0) (k/n)/(M/N) else NA_real_,
                 pvalue=p,padj=NA_real_,stringsAsFactors=FALSE)
    }))
    if(!is.null(sets_output)) {
      eligible <- sets_output$status=="tested"
      sets_output$padj[eligible] <- p.adjust(sets_output$pvalue[eligible],method="BH")
    } else sets_output <- data.frame(set_id=character(),status=character(),pvalue=numeric(),padj=numeric())
    write_table(sets_output,"gene-set-enrichment.csv")
    membership_rows <- do.call(rbind,lapply(a$geneSets,function(s){
      members <- unique(unlist(s$genes,use.names=FALSE))
      data.frame(set_id=s$id,gene_id=members,in_counts=members %in% genes,in_universe=members %in% universe,selected=members %in% selected)
    }))
    if(!is.null(membership_rows))write_table(membership_rows,"gene-set-membership-audit.csv")
    enrichment <- list(status=if(length(universe))"completed" else "not_estimable", method="right-tail hypergeometric / BH over size-eligible sets",
                       universe="Genes with finite DESeq2 BH adjusted p values after count, Cook's and optional independent filtering",
                       universeSize=length(universe),selected=length(selected),direction=o$geneSets$direction,
                       source=o$geneSets$source,version=o$geneSets$version,sets=nrow(sets_output),
                       tested=sum(sets_output$status=="tested"),significant=sum(sets_output$padj<o$alpha,na.rm=TRUE))
  }
  meta <- metadata(result)
  saveRDS(result,"deseq2-results.rds",compress="xz")
  write_json_file(list(alpha=o$alpha,enabled=o$independentFiltering,threshold=meta$filterThreshold,
                      theta=meta$filterTheta,rejectionCurve=meta$filterNumRej,smoothing=meta$lo.fit),"independent-filtering.json")
  actual_fit <- attr(dispersionFunction(dds),"fitType")
  numeric_result <- list(contract="genomics-deseq2-v1", options=o, analysisHash=payload$analysisHash,
     design=qc, package=list(R=as.character(getRversion()),DESeq2=as.character(packageVersion("DESeq2"))),
     method=list(test="negative-binomial GLM / Wald",contrast=as.list(contrast),lfc="unshrunken maximum-likelihood log2 fold change",confidenceLevel=.95,
                 sizeFactor=o$sizeFactor,fitRequested=o$fitType,fitActual=actual_fit,alpha=o$alpha,pAdjust="BH",
                 lfcThreshold=o$lfcThreshold,alternative="greaterAbs",independentFiltering=o$independentFiltering,
                 statistic="log2FoldChange / lfcSE",pValueFormula="Phi((T - |LFC|) / SE) + Phi((-T - |LFC|) / SE); T = lfcThreshold",
                 filterThreshold=if(is.null(meta$filterThreshold))NULL else unname(meta$filterThreshold),
                 cooksFiltering="DESeq2 default, replicate-pattern dependent",automaticCountReplacement=FALSE),
     summary=list(inputGenes=length(genes),samples=length(samples),prefilterRetained=sum(keep),allZero=sum(all_zero),
                  lowCount=sum(!keep & !all_zero),tested=sum(output$status=="tested"),independentFiltered=sum(status=="independent_filtered"),
                  cooksOutlier=sum(status=="cooks_outlier"),notEstimable=sum(status=="not_estimable"),
                  significant=sum(output$significant),up=sum(output$significant & output$log2FoldChange>0,na.rm=TRUE),
                  down=sum(output$significant & output$log2FoldChange<0,na.rm=TRUE)),
     samples=sample_qc, topGenes=head(output[order(output$padj,na.last=TRUE),],30),enrichment=enrichment,
     warnings=as.list(unique(c(unlist(a$warnings),warnings_seen))))
  write_json_file(numeric_result,"numeric-result.json")
  file.copy("/opt/genomics/packages.csv","packages.csv",overwrite=TRUE)
  writeLines(capture.output(sessionInfo()),"session.txt")

  vsd <- varianceStabilizingTransformation(dds,blind=FALSE)
  transformed <- assay(vsd)
  write_matrix(transformed,"variance-stabilized-counts.csv.gz")
  variances <- matrixStats::rowVars(transformed)
  variable <- which(is.finite(variances) & variances>0)
  chosen <- head(variable[order(variances[variable],decreasing=TRUE)],500)
  palette <- grDevices::hcl.colors(length(original_levels),"Dark 3")
  colors <- palette[match(conditions,original_levels)]
  figure <- function(file, expression, width=1800,height=1300) {
    png(file,width=width,height=height,res=150,type="cairo",family="Noto Sans CJK TC")
    on.exit(dev.off())
    force(expression)
  }
  if(length(chosen)>=2) {
    pca <- prcomp(t(transformed[chosen,,drop=FALSE]),center=TRUE,scale.=FALSE)
    fraction <- pca$sdev^2/sum(pca$sdev^2)
    pca_table <- data.frame(sample_id=sample_ids,condition=conditions,PC1=pca$x[,1],PC2=pca$x[,2])
    write_table(pca_table,"pca-coordinates.csv")
    numeric_result$pca <- list(status="completed",genes=as.list(rownames(transformed)[chosen]),PC1=fraction[[1]],PC2=fraction[[2]],
      transform="DESeq2 varianceStabilizingTransformation, blind=FALSE; batch effects are not removed")
    figure("pca.png",{
      p <- ggplot2::ggplot(pca_table,ggplot2::aes(x=PC1,y=PC2,color=condition)) +
        ggplot2::geom_point(size=2.8) +
        ggplot2::scale_color_manual(values=setNames(palette,original_levels)) +
        ggplot2::labs(title="樣本 PCA · VST",subtitle=paste0(length(chosen)," 個高變異基因；批次差異未移除"),
                      x=sprintf("PC1 (%.1f%%)",100*fraction[1]),y=sprintf("PC2 (%.1f%%)",100*fraction[2])) +
        ggplot2::theme_minimal(base_size=13,base_family="Noto Sans CJK TC")
      if(length(samples)<=30) p <- p + ggrepel::geom_text_repel(ggplot2::aes(label=sample_id),seed=260924,max.overlaps=Inf,
                                    box.padding=.6,force=3,min.segment.length=0,size=3.5,show.legend=FALSE)
      print(p)
    })
  } else {
    numeric_result$pca <- list(status="not_estimable",reason="Fewer than two variable transformed genes")
    figure("pca.png",{plot.new();text(.5,.5,"PCA 無法估計：可變動基因不足")})
  }
  distances <- as.matrix(dist(t(transformed)))
  write_matrix(distances,"sample-distances.csv.gz",key="sample_id")
  # Freeze plotting coordinates and fitted values while the actual DESeq2 model
  # is in memory. Journal editions consume this file without loading/refitting RDS.
  dispersion_table <- data.frame(gene_id=rownames(dds), baseMean=mcols(dds)$baseMean,
    geneWise=mcols(dds)$dispGeneEst, fitted=mcols(dds)$dispFit, final=dispersions(dds))
  write_table(dispersion_table,"dispersion-estimates.csv")
  distance_rows <- lapply(seq_along(sample_ids),function(i)
    list(sample_id=sample_ids[[i]],values=as.list(unname(distances[i,]))))
  write_json_file(list(schema="genomics-publication-data-v1",analysisHash=payload$analysisHash,
    options=o,method=numeric_result$method,package=numeric_result$package,design=qc,
    summary=numeric_result$summary,genes=output,samples=sample_qc,pca=numeric_result$pca,
    pca_coordinates=if(numeric_result$pca$status=="completed")pca_table else list(),
    sample_distances=distance_rows,dispersion=dispersion_table,
    enrichment=enrichment,gene_sets=if(is.null(sets_output))list() else sets_output,
    warnings=as.list(unique(c(unlist(a$warnings),warnings_seen)))),"publication-data.json")
  figure("sample-distances.png",{
    distance_table <- data.frame(sample_x=factor(rep(sample_ids,each=length(samples)),levels=sample_ids),
                                 sample_y=factor(rep(sample_ids,length(samples)),levels=rev(sample_ids)),
                                 distance=as.vector(distances))
    labels <- if(length(samples)<=60) ggplot2::waiver() else NULL
    print(ggplot2::ggplot(distance_table,ggplot2::aes(x=sample_x,y=sample_y,fill=distance)) +
      ggplot2::geom_raster() + ggplot2::coord_equal() +
      ggplot2::scale_fill_gradient(low="#f1f7f5",high="#14574f",limits=c(0,max(distances)),name="Euclidean\n距離") +
      ggplot2::scale_x_discrete(labels=labels) + ggplot2::scale_y_discrete(labels=labels) +
      ggplot2::labs(title="樣本距離 · VST",subtitle="依 counts 樣本順序排列；完整數值另附 CSV",x=NULL,y=NULL) +
      ggplot2::theme_minimal(base_size=13,base_family="Noto Sans CJK TC") +
      ggplot2::theme(panel.grid=ggplot2::element_blank(),axis.text.x=ggplot2::element_text(angle=90,hjust=1,vjust=.5),
                     plot.margin=ggplot2::margin(15,20,15,15),legend.title=ggplot2::element_text(size=11)))
  })
  figure("ma.png",{
    estimable <- is.finite(output$log2FoldChange)
    if(any(estimable)) {
      plot(log10(output$baseMean[estimable]+1),output$log2FoldChange[estimable],pch=16,cex=.45,
           col=ifelse(output$significant[estimable],"#bc5146","#778a88"),
           xlab="log10(normalized mean + 1)",ylab=paste0("log2 FC: ",o$numerator," / ",o$reference),main="MA · unshrunken log2 FC")
      abline(h=0,col="#174e49",lty=2)
    } else {plot.new();text(.5,.5,"無可估計的 fold change")}
  })
  figure("volcano.png",{
    estimable <- is.finite(output$log2FoldChange) & is.finite(output$padj)
    if(any(estimable)) {
      plot(output$log2FoldChange[estimable],-log10(pmax(output$padj[estimable],1e-300)),pch=16,cex=.45,
           col=ifelse(output$significant[estimable],"#bc5146","#778a88"),
           xlab=paste0("log2 FC: ",o$numerator," / ",o$reference),ylab="-log10(BH adjusted p), capped at 300",main="差異表現 · BH FDR")
      abline(h=-log10(o$alpha),col="#174e49",lty=2)
      if(o$lfcThreshold>0)abline(v=c(-o$lfcThreshold,o$lfcThreshold),lty=3)
    } else {plot.new();text(.5,.5,"沒有可估計的 BH adjusted p")}
  })
  figure("dispersion.png",plotDispEsts(dds,main="DESeq2 dispersion estimates"))
  numeric_result$warnings <- as.list(unique(c(unlist(a$warnings),warnings_seen)))
  write_json_file(numeric_result,"result.json")
}
withCallingHandlers(run(),warning=function(w){
  warnings_seen <<- c(warnings_seen,conditionMessage(w))
})
